import { put } from '@vercel/blob';
import crypto from 'node:crypto';

function makeId(){
  return crypto.randomBytes(6).toString('base64url');
}

function safeText(v,max){
  return String(v ?? '').trim().slice(0,max);
}

export default async function handler(req,res){
  if(req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
  try{
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    if(!body || typeof body !== 'object') return res.status(400).json({error:'بيانات غير صحيحة'});

    const data = {
      type:safeText(body.type,60) || 'Birthday',
      receiver:safeText(body.receiver,80),
      sender:safeText(body.sender,80),
      message:safeText(body.message,2000),
      color:/^#[0-9a-fA-F]{6}$/.test(String(body.color||'')) ? String(body.color) : '#8b5cf6',
      albumStyle:body.albumStyle === 'book' ? 'book' : 'slider',
      images:Array.isArray(body.images) ? body.images.slice(0,8).map(v=>String(v).slice(0,1000)) : [],
      music:(body.music && body.music.value) ? {type:'url',value:String(body.music.value).slice(0,2000),name:safeText(body.music.name,160)} : {type:'none',value:''},
      createdAt:new Date().toISOString()
    };

    if(data.receiver.length < 2 || data.sender.length < 2 || data.message.length < 3){
      return res.status(400).json({error:'أكمل بيانات التهنئة أولاً'});
    }

    let id='';
    for(let i=0;i<5;i++){
      id=makeId();
      try{
        await put(`greetings/${id}.json`, JSON.stringify(data), {access:'public',contentType:'application/json',addRandomSuffix:false});
        break;
      }catch(err){
        if(i===4) throw err;
      }
    }
    return res.status(200).json({id});
  }catch(err){
    console.error(err);
    return res.status(500).json({error:'فشل حفظ التهنئة'});
  }
}
