import { head } from '@vercel/blob';

export default async function handler(req,res){
  if(req.method !== 'GET') return res.status(405).json({error:'Method not allowed'});
  const id = String(req.query.id || '');
  if(!/^[A-Za-z0-9_-]{4,64}$/.test(id)) return res.status(400).json({error:'رابط تهنئة غير صحيح'});
  try{
    const meta = await head(`greetings/${id}.json`);
    const response = await fetch(meta.url, {cache:'no-store'});
    if(!response.ok) return res.status(404).json({error:'التهنئة غير موجودة'});
    const data = await response.json();
    return res.status(200).json({data});
  }catch(err){
    console.error(err);
    return res.status(404).json({error:'التهنئة غير موجودة أو انتهت صلاحيتها'});
  }
}
