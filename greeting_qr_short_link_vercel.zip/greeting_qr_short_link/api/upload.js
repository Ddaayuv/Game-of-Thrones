import { put } from '@vercel/blob';
import crypto from 'node:crypto';

export const config = { api: { bodyParser: false, sizeLimit: '10mb' } };

function readBody(req){
  return new Promise((resolve,reject)=>{
    const chunks=[];
    req.on('data',c=>chunks.push(Buffer.from(c)));
    req.on('end',()=>resolve(Buffer.concat(chunks)));
    req.on('error',reject);
  });
}

function cleanName(name){
  return String(name || 'file').replace(/[^a-zA-Z0-9._-]+/g,'_').slice(-120) || 'file';
}

export default async function handler(req,res){
  if(req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
  try{
    const body = req.body && Buffer.isBuffer(req.body) ? req.body : await readBody(req);
    if(!body.length) return res.status(400).json({error:'الملف فارغ'});
    if(body.length > 9 * 1024 * 1024) return res.status(413).json({error:'حجم الملف كبير جداً'});

    const folder = ['images','audio'].includes(String(req.query.folder)) ? String(req.query.folder) : 'misc';
    const name = cleanName(req.headers['x-file-name']);
    const contentType = String(req.headers['content-type'] || 'application/octet-stream');
    const pathname = `${folder}/${Date.now()}-${crypto.randomUUID()}-${name}`;
    const blob = await put(pathname, body, { access:'public', contentType });
    return res.status(200).json({url:blob.url});
  }catch(err){
    console.error(err);
    return res.status(500).json({error:'فشل رفع الملف'});
  }
}
